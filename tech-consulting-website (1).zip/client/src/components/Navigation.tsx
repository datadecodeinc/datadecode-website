import { BarChart3 } from "lucide-react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { APP_TITLE } from "@/const";

export default function Navigation() {
  const [location] = useLocation();

  const isActive = (path: string) => {
    return location === path;
  };

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-lg border-b border-border">
      <div className="container mx-auto">
        <div className="flex items-center justify-between h-16">
          <Link href="/">
            <a className="flex items-center space-x-2 hover:opacity-80 transition-opacity">
              <BarChart3 className="h-6 w-6 text-primary" />
              <span className="text-xl font-bold text-foreground">{APP_TITLE}</span>
            </a>
          </Link>
          <div className="flex items-center space-x-8">
            <Link href="/">
              <a className={`text-sm font-medium transition-colors ${
                isActive('/') ? 'text-foreground' : 'text-muted-foreground hover:text-foreground'
              }`}>
                Home
              </a>
            </Link>
            <Link href="/about">
              <a className={`text-sm font-medium transition-colors ${
                isActive('/about') ? 'text-foreground' : 'text-muted-foreground hover:text-foreground'
              }`}>
                About
              </a>
            </Link>
            <Link href="/services">
              <a className={`text-sm font-medium transition-colors ${
                isActive('/services') ? 'text-foreground' : 'text-muted-foreground hover:text-foreground'
              }`}>
                Services
              </a>
            </Link>
            <Link href="/contact">
              <a className={`text-sm font-medium transition-colors ${
                isActive('/contact') ? 'text-foreground' : 'text-muted-foreground hover:text-foreground'
              }`}>
                Contact
              </a>
            </Link>
            <Link href="/contact">
              <Button size="sm">
                Get Started
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
}
