import { BarChart3 } from "lucide-react";
import { Link } from "wouter";
import { APP_TITLE } from "@/const";

export default function Footer() {
  return (
    <footer className="bg-muted/30 border-t border-border py-12">
      <div className="container">
        <div className="grid md:grid-cols-4 gap-8 mb-8">
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <BarChart3 className="h-6 w-6 text-primary" />
              <span className="text-lg font-bold text-foreground">{APP_TITLE}</span>
            </div>
            <p className="text-sm text-muted-foreground">
              Transforming data into actionable business intelligence with 15 years of expertise.
            </p>
          </div>
          <div>
            <h4 className="font-semibold mb-4 text-foreground">Services</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>
                <Link href="/services">
                  <a className="hover:text-foreground transition-colors">Data Analytics</a>
                </Link>
              </li>
              <li>
                <Link href="/services">
                  <a className="hover:text-foreground transition-colors">Data Engineering</a>
                </Link>
              </li>
              <li>
                <Link href="/services">
                  <a className="hover:text-foreground transition-colors">Power BI</a>
                </Link>
              </li>
              <li>
                <Link href="/services">
                  <a className="hover:text-foreground transition-colors">Tableau</a>
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold mb-4 text-foreground">Company</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>
                <Link href="/about">
                  <a className="hover:text-foreground transition-colors">About</a>
                </Link>
              </li>
              <li>
                <Link href="/contact">
                  <a className="hover:text-foreground transition-colors">Contact</a>
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold mb-4 text-foreground">Contact</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>
                <a href="mailto:contact@datadecode.com" className="hover:text-foreground transition-colors">
                  contact@datadecode.com
                </a>
              </li>
              <li>
                <a href="tel:+1234567890" className="hover:text-foreground transition-colors">
                  +1 (234) 567-890
                </a>
              </li>
            </ul>
          </div>
        </div>
        <div className="border-t border-border pt-8 text-center text-sm text-muted-foreground">
          <p>&copy; {new Date().getFullYear()} {APP_TITLE}. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
