import { BarChart3, Database, LineChart, TrendingUp, Code2, Cloud } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function Services() {
  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="pt-32 pb-20 bg-gradient-to-br from-primary/5 via-accent/5 to-background">
        <div className="container">
          <div className="max-w-4xl mx-auto text-center space-y-6">
            <h1 className="text-5xl md:text-6xl font-bold text-foreground">
              Our Services
            </h1>
            <p className="text-xl text-muted-foreground leading-relaxed">
              Comprehensive data solutions built on industry-leading platforms and technologies to drive business intelligence and operational excellence.
            </p>
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20 bg-background">
        <div className="container">
          <div className="max-w-6xl mx-auto space-y-16">
            {/* Data Engineering */}
            <Card className="border-border bg-card overflow-hidden">
              <div className="grid md:grid-cols-3 gap-8 p-8">
                <div className="md:col-span-2 space-y-4">
                  <div className="h-14 w-14 rounded-xl bg-accent/10 flex items-center justify-center">
                    <Database className="h-7 w-7 text-accent" />
                  </div>
                  <CardTitle className="text-3xl text-card-foreground">Data Engineering</CardTitle>
                  <CardDescription className="text-base leading-relaxed">
                    Build scalable, reliable data infrastructure that forms the foundation for analytics and business intelligence. We design and implement modern data architectures that handle massive volumes of data while maintaining performance and cost efficiency.
                  </CardDescription>
                  <div className="space-y-3 pt-4">
                    <h4 className="font-semibold text-card-foreground">Key Capabilities:</h4>
                    <ul className="space-y-2 text-muted-foreground text-sm">
                      <li className="flex items-start">
                        <span className="text-accent mr-2">•</span>
                        Cloud data platform architecture (Azure Synapse, Databricks, Snowflake)
                      </li>
                      <li className="flex items-start">
                        <span className="text-accent mr-2">•</span>
                        ETL/ELT pipeline development with Azure Data Factory, Apache Spark
                      </li>
                      <li className="flex items-start">
                        <span className="text-accent mr-2">•</span>
                        Data warehouse and lakehouse design and optimization
                      </li>
                      <li className="flex items-start">
                        <span className="text-accent mr-2">•</span>
                        Real-time data streaming (Apache Kafka, Azure Event Hubs)
                      </li>
                      <li className="flex items-start">
                        <span className="text-accent mr-2">•</span>
                        Database design, optimization, and SQL performance tuning
                      </li>
                      <li className="flex items-start">
                        <span className="text-accent mr-2">•</span>
                        Data quality frameworks and validation pipelines
                      </li>
                      <li className="flex items-start">
                        <span className="text-accent mr-2">•</span>
                        Data governance and metadata management
                      </li>
                    </ul>
                  </div>
                  <div className="pt-4">
                    <h4 className="font-semibold text-card-foreground mb-2">Technologies:</h4>
                    <div className="flex flex-wrap gap-2">
                      {['Databricks', 'Azure Synapse', 'Snowflake', 'Azure Data Factory', 'SQL', 'Apache Spark', 'Python', 'Apache Kafka'].map((tech) => (
                        <span key={tech} className="px-3 py-1 bg-accent/10 text-accent-foreground text-xs rounded-full">
                          {tech}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
                <div className="flex items-center justify-center">
                  <img 
                    src="/data-engineering.jpeg" 
                    alt="Data Engineering" 
                    className="rounded-lg w-full h-48 object-cover"
                  />
                </div>
              </div>
            </Card>

            {/* Data Analytics */}
            <Card className="border-border bg-card overflow-hidden">
              <div className="grid md:grid-cols-3 gap-8 p-8">
                <div className="md:col-span-2 space-y-4">
                  <div className="h-14 w-14 rounded-xl bg-primary/10 flex items-center justify-center">
                    <BarChart3 className="h-7 w-7 text-primary" />
                  </div>
                  <CardTitle className="text-3xl text-card-foreground">Data Analytics</CardTitle>
                  <CardDescription className="text-base leading-relaxed">
                    Transform raw data into actionable insights through advanced analytics, statistical modeling, and exploratory data analysis. We help you understand patterns, predict trends, and identify opportunities for business optimization.
                  </CardDescription>
                  <div className="space-y-3 pt-4">
                    <h4 className="font-semibold text-card-foreground">Key Capabilities:</h4>
                    <ul className="space-y-2 text-muted-foreground text-sm">
                      <li className="flex items-start">
                        <span className="text-primary mr-2">•</span>
                        Exploratory data analysis and statistical modeling
                      </li>
                      <li className="flex items-start">
                        <span className="text-primary mr-2">•</span>
                        Predictive analytics and forecasting models
                      </li>
                      <li className="flex items-start">
                        <span className="text-primary mr-2">•</span>
                        Customer segmentation and behavioral analysis
                      </li>
                      <li className="flex items-start">
                        <span className="text-primary mr-2">•</span>
                        A/B testing and experimental design
                      </li>
                      <li className="flex items-start">
                        <span className="text-primary mr-2">•</span>
                        Performance metrics, KPI tracking, and reporting
                      </li>
                      <li className="flex items-start">
                        <span className="text-primary mr-2">•</span>
                        Root cause analysis and business intelligence
                      </li>
                      <li className="flex items-start">
                        <span className="text-primary mr-2">•</span>
                        Data-driven recommendations and insights
                      </li>
                    </ul>
                  </div>
                  <div className="pt-4">
                    <h4 className="font-semibold text-card-foreground mb-2">Technologies:</h4>
                    <div className="flex flex-wrap gap-2">
                      {['Python', 'R', 'SQL', 'Apache Spark', 'Databricks', 'Pandas', 'NumPy', 'Scikit-learn'].map((tech) => (
                        <span key={tech} className="px-3 py-1 bg-primary/10 text-primary text-xs rounded-full">
                          {tech}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
                <div className="flex items-center justify-center">
                  <img 
                    src="/hero-bg.png" 
                    alt="Data Analytics" 
                    className="rounded-lg w-full h-48 object-cover"
                  />
                </div>
              </div>
            </Card>

            {/* Business Intelligence & Visualization */}
            <Card className="border-border bg-card overflow-hidden">
              <div className="grid md:grid-cols-3 gap-8 p-8">
                <div className="md:col-span-2 space-y-4">
                  <div className="h-14 w-14 rounded-xl bg-primary/10 flex items-center justify-center">
                    <LineChart className="h-7 w-7 text-primary" />
                  </div>
                  <CardTitle className="text-3xl text-card-foreground">Business Intelligence & Visualization</CardTitle>
                  <CardDescription className="text-base leading-relaxed">
                    Create compelling, interactive dashboards and reports that empower stakeholders to make data-driven decisions. We design visualizations that communicate complex data stories clearly and drive business action.
                  </CardDescription>
                  <div className="space-y-3 pt-4">
                    <h4 className="font-semibold text-card-foreground">Key Capabilities:</h4>
                    <ul className="space-y-2 text-muted-foreground text-sm">
                      <li className="flex items-start">
                        <span className="text-primary mr-2">•</span>
                        Power BI dashboard and report development
                      </li>
                      <li className="flex items-start">
                        <span className="text-primary mr-2">•</span>
                        Tableau visualization and interactive analytics
                      </li>
                      <li className="flex items-start">
                        <span className="text-primary mr-2">•</span>
                        Data modeling and DAX/MDX optimization
                      </li>
                      <li className="flex items-start">
                        <span className="text-primary mr-2">•</span>
                        Self-service analytics enablement and training
                      </li>
                      <li className="flex items-start">
                        <span className="text-primary mr-2">•</span>
                        Real-time dashboards and monitoring solutions
                      </li>
                      <li className="flex items-start">
                        <span className="text-primary mr-2">•</span>
                        Executive scorecards and KPI dashboards
                      </li>
                      <li className="flex items-start">
                        <span className="text-primary mr-2">•</span>
                        Data storytelling and visualization best practices
                      </li>
                    </ul>
                  </div>
                  <div className="pt-4">
                    <h4 className="font-semibold text-card-foreground mb-2">Technologies:</h4>
                    <div className="flex flex-wrap gap-2">
                      {['Power BI', 'Tableau', 'DAX', 'M Language', 'SQL', 'Python', 'Azure Analysis Services', 'Looker'].map((tech) => (
                        <span key={tech} className="px-3 py-1 bg-primary/10 text-primary text-xs rounded-full">
                          {tech}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
                <div className="flex items-center justify-center">
                  <div className="w-full h-48 rounded-lg bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center">
                    <LineChart className="h-20 w-20 text-primary/40" />
                  </div>
                </div>
              </div>
            </Card>

            {/* Cloud Data Platforms */}
            <Card className="border-border bg-card overflow-hidden">
              <div className="grid md:grid-cols-3 gap-8 p-8">
                <div className="md:col-span-2 space-y-4">
                  <div className="h-14 w-14 rounded-xl bg-accent/10 flex items-center justify-center">
                    <Cloud className="h-7 w-7 text-accent" />
                  </div>
                  <CardTitle className="text-3xl text-card-foreground">Cloud Data Platform Implementation</CardTitle>
                  <CardDescription className="text-base leading-relaxed">
                    Migrate, implement, and optimize your data infrastructure on leading cloud platforms. We provide end-to-end support for cloud data platform adoption, ensuring seamless transition and maximum value realization.
                  </CardDescription>
                  <div className="space-y-3 pt-4">
                    <h4 className="font-semibold text-card-foreground">Key Capabilities:</h4>
                    <ul className="space-y-2 text-muted-foreground text-sm">
                      <li className="flex items-start">
                        <span className="text-accent mr-2">•</span>
                        Azure Synapse Analytics implementation and optimization
                      </li>
                      <li className="flex items-start">
                        <span className="text-accent mr-2">•</span>
                        Databricks workspace setup and Delta Lake architecture
                      </li>
                      <li className="flex items-start">
                        <span className="text-accent mr-2">•</span>
                        Snowflake data warehouse design and administration
                      </li>
                      <li className="flex items-start">
                        <span className="text-accent mr-2">•</span>
                        AWS data services (Redshift, Glue, EMR, S3)
                      </li>
                      <li className="flex items-start">
                        <span className="text-accent mr-2">•</span>
                        Cloud cost optimization and performance tuning
                      </li>
                      <li className="flex items-start">
                        <span className="text-accent mr-2">•</span>
                        Data migration and legacy system modernization
                      </li>
                      <li className="flex items-start">
                        <span className="text-accent mr-2">•</span>
                        Cloud security, compliance, and governance
                      </li>
                    </ul>
                  </div>
                  <div className="pt-4">
                    <h4 className="font-semibold text-card-foreground mb-2">Technologies:</h4>
                    <div className="flex flex-wrap gap-2">
                      {['Azure Synapse', 'Databricks', 'Snowflake', 'AWS Redshift', 'Google BigQuery', 'Azure Data Lake', 'Apache Spark', 'Terraform'].map((tech) => (
                        <span key={tech} className="px-3 py-1 bg-accent/10 text-accent-foreground text-xs rounded-full">
                          {tech}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
                <div className="flex items-center justify-center">
                  <div className="w-full h-48 rounded-lg bg-gradient-to-br from-accent/20 to-primary/20 flex items-center justify-center">
                    <Cloud className="h-20 w-20 text-accent/40" />
                  </div>
                </div>
              </div>
            </Card>

            {/* Consulting & Strategy */}
            <Card className="border-border bg-card overflow-hidden">
              <div className="grid md:grid-cols-3 gap-8 p-8">
                <div className="md:col-span-2 space-y-4">
                  <div className="h-14 w-14 rounded-xl bg-primary/10 flex items-center justify-center">
                    <TrendingUp className="h-7 w-7 text-primary" />
                  </div>
                  <CardTitle className="text-3xl text-card-foreground">Data Strategy & Consulting</CardTitle>
                  <CardDescription className="text-base leading-relaxed">
                    Develop a comprehensive data strategy aligned with your business objectives. We provide strategic guidance on data architecture, technology selection, and organizational capabilities to maximize ROI and competitive advantage.
                  </CardDescription>
                  <div className="space-y-3 pt-4">
                    <h4 className="font-semibold text-card-foreground">Key Capabilities:</h4>
                    <ul className="space-y-2 text-muted-foreground text-sm">
                      <li className="flex items-start">
                        <span className="text-primary mr-2">•</span>
                        Data strategy and roadmap development
                      </li>
                      <li className="flex items-start">
                        <span className="text-primary mr-2">•</span>
                        Technology assessment and platform selection
                      </li>
                      <li className="flex items-start">
                        <span className="text-primary mr-2">•</span>
                        Data governance and organizational design
                      </li>
                      <li className="flex items-start">
                        <span className="text-primary mr-2">•</span>
                        Capability building and team training
                      </li>
                      <li className="flex items-start">
                        <span className="text-primary mr-2">•</span>
                        Cost-benefit analysis and ROI modeling
                      </li>
                      <li className="flex items-start">
                        <span className="text-primary mr-2">•</span>
                        Change management and adoption support
                      </li>
                      <li className="flex items-start">
                        <span className="text-primary mr-2">•</span>
                        Use case identification and prioritization
                      </li>
                    </ul>
                  </div>
                </div>
                <div className="flex items-center justify-center">
                  <div className="w-full h-48 rounded-lg bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center">
                    <TrendingUp className="h-20 w-20 text-primary/40" />
                  </div>
                </div>
              </div>
            </Card>
          </div>

          {/* CTA Section */}
          <div className="max-w-4xl mx-auto mt-20 text-center space-y-6">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground">
              Ready to Transform Your Data?
            </h2>
            <p className="text-lg text-muted-foreground">
              Let's discuss how our services can help your organization achieve its data and analytics goals.
            </p>
            <Link href="/contact">
              <Button size="lg" className="text-lg px-8 py-6">
                Schedule a Consultation
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
