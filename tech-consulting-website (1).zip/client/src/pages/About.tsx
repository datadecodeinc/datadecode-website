import { Award, Briefcase, Target, Users } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function About() {
  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="pt-32 pb-20 bg-gradient-to-br from-primary/5 via-accent/5 to-background">
        <div className="container">
          <div className="max-w-4xl mx-auto text-center space-y-6">
            <h1 className="text-5xl md:text-6xl font-bold text-foreground">
              About Data Decode Inc.
            </h1>
            <p className="text-xl text-muted-foreground leading-relaxed">
              A dedicated team of data professionals committed to delivering enterprise-grade data solutions.
            </p>
          </div>
        </div>
      </section>

      {/* Company Overview */}
      <section className="py-20 bg-background">
        <div className="container">
          <div className="max-w-4xl mx-auto space-y-12">
            <div className="space-y-6">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground">Our Mission</h2>
              <p className="text-lg text-muted-foreground leading-relaxed">
                At Data Decode Inc., we empower businesses to unlock the full potential of their data. We specialize in designing, building, and optimizing data infrastructure and analytics solutions that drive strategic decision-making and measurable business outcomes. Our team brings deep expertise in modern data platforms, cloud technologies, and business intelligence tools to deliver solutions tailored to your unique needs.
              </p>
            </div>

            {/* Core Values */}
            <div className="space-y-6">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground">Our Approach</h2>
              <div className="grid md:grid-cols-2 gap-6">
                <Card className="border-border bg-card">
                  <CardHeader>
                    <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                      <Target className="h-6 w-6 text-primary" />
                    </div>
                    <CardTitle className="text-card-foreground">Strategic Focus</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">
                      We align data solutions with your business objectives, ensuring every implementation delivers measurable ROI and strategic value.
                    </p>
                  </CardContent>
                </Card>

                <Card className="border-border bg-card">
                  <CardHeader>
                    <div className="h-12 w-12 rounded-lg bg-accent/10 flex items-center justify-center mb-4">
                      <Briefcase className="h-6 w-6 text-accent" />
                    </div>
                    <CardTitle className="text-card-foreground">Technical Excellence</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">
                      Our team stays current with industry best practices and cutting-edge technologies to deliver scalable, maintainable solutions.
                    </p>
                  </CardContent>
                </Card>

                <Card className="border-border bg-card">
                  <CardHeader>
                    <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                      <Users className="h-6 w-6 text-primary" />
                    </div>
                    <CardTitle className="text-card-foreground">Collaborative Partnership</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">
                      We work closely with your team, providing knowledge transfer and support to ensure long-term success and adoption.
                    </p>
                  </CardContent>
                </Card>

                <Card className="border-border bg-card">
                  <CardHeader>
                    <div className="h-12 w-12 rounded-lg bg-accent/10 flex items-center justify-center mb-4">
                      <Award className="h-6 w-6 text-accent" />
                    </div>
                    <CardTitle className="text-card-foreground">Quality Assurance</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">
                      Rigorous testing, validation, and optimization ensure your data infrastructure is reliable, secure, and performant.
                    </p>
                  </CardContent>
                </Card>
              </div>
            </div>

            {/* Expertise Areas */}
            <div className="space-y-6 pt-8">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground">Our Expertise</h2>
              <p className="text-lg text-muted-foreground leading-relaxed">
                Our team has extensive experience across the full spectrum of data analytics and engineering disciplines. We work with leading cloud platforms, modern data warehousing solutions, and enterprise business intelligence tools to build solutions that scale with your business.
              </p>
              <div className="grid md:grid-cols-2 gap-8">
                <div className="space-y-4">
                  <h3 className="text-xl font-semibold text-foreground">Data Engineering</h3>
                  <ul className="space-y-2 text-muted-foreground">
                    <li className="flex items-start">
                      <span className="text-primary mr-3 font-bold">•</span>
                      <span>Cloud data platforms (Azure, AWS, GCP)</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-primary mr-3 font-bold">•</span>
                      <span>Data warehousing and lakehouse architectures</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-primary mr-3 font-bold">•</span>
                      <span>ETL/ELT pipeline design and optimization</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-primary mr-3 font-bold">•</span>
                      <span>Real-time data streaming and processing</span>
                    </li>
                  </ul>
                </div>
                <div className="space-y-4">
                  <h3 className="text-xl font-semibold text-foreground">Data Analytics & BI</h3>
                  <ul className="space-y-2 text-muted-foreground">
                    <li className="flex items-start">
                      <span className="text-accent mr-3 font-bold">•</span>
                      <span>Advanced analytics and statistical modeling</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-accent mr-3 font-bold">•</span>
                      <span>Interactive dashboard and report development</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-accent mr-3 font-bold">•</span>
                      <span>Data visualization and storytelling</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-accent mr-3 font-bold">•</span>
                      <span>Self-service analytics enablement</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Why Choose Us */}
            <div className="space-y-6 pt-8 bg-muted/30 p-8 rounded-lg">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground">Why Choose Data Decode Inc.</h2>
              <div className="grid md:grid-cols-3 gap-6">
                <div className="text-center">
                  <div className="text-3xl font-bold text-primary mb-2">Industry-Leading</div>
                  <p className="text-muted-foreground">
                    Expertise with enterprise-grade technologies and platforms trusted by Fortune 500 companies.
                  </p>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-accent mb-2">End-to-End</div>
                  <p className="text-muted-foreground">
                    From architecture design to implementation and support, we handle the complete data journey.
                  </p>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-primary mb-2">Proven Track Record</div>
                  <p className="text-muted-foreground">
                    Successful delivery of complex data projects across diverse industries and use cases.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
