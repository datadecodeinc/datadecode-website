import { Button } from "@/components/ui/button";
import { Card, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart3, Database, LineChart, TrendingUp, Cloud, Code2 } from "lucide-react";
import { Link } from "wouter";

export default function Home() {
  const technologies = [
    { name: 'Databricks', category: 'Data Engineering' },
    { name: 'Azure Synapse', category: 'Cloud Platform' },
    { name: 'Snowflake', category: 'Data Warehouse' },
    { name: 'Azure Data Factory', category: 'ETL' },
    { name: 'Power BI', category: 'BI & Visualization' },
    { name: 'Tableau', category: 'BI & Visualization' },
    { name: 'SQL', category: 'Database' },
    { name: 'Python', category: 'Analytics' },
    { name: 'Apache Spark', category: 'Data Processing' },
    { name: 'Kafka', category: 'Streaming' },
    { name: 'AWS Services', category: 'Cloud Platform' },
    { name: 'Google BigQuery', category: 'Cloud Platform' },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Hero Section */}
      <section className="relative pt-32 pb-24 overflow-hidden bg-gradient-to-br from-primary/5 via-accent/5 to-background">
        <div 
          className="absolute inset-0 opacity-5"
          style={{
            backgroundImage: 'url(/hero-bg.png)',
            backgroundSize: 'cover',
            backgroundPosition: 'center',
          }}
        />
        <div className="container relative z-10">
          <div className="max-w-4xl mx-auto text-center space-y-8">
            <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold leading-tight text-foreground">
              Enterprise-Grade{" "}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent">
                Data Solutions
              </span>
            </h1>
            <p className="text-xl md:text-2xl text-muted-foreground leading-relaxed max-w-3xl mx-auto">
              Data Decode Inc. delivers comprehensive data engineering, analytics, and business intelligence solutions on modern cloud platforms. We help organizations unlock the full potential of their data.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
              <Link href="/contact">
                <Button size="lg" className="text-lg px-8 py-6">
                  Start Your Project
                </Button>
              </Link>
              <Link href="/services">
                <Button size="lg" variant="outline" className="text-lg px-8 py-6">
                  Explore Services
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Services Overview */}
      <section className="py-20 bg-background">
        <div className="container">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6 text-foreground">
              What We Deliver
            </h2>
            <p className="text-xl text-muted-foreground">
              End-to-end data solutions spanning engineering, analytics, and business intelligence to drive measurable business outcomes.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
            <Card className="group hover:shadow-xl transition-all duration-300 hover:-translate-y-1 border-border bg-card">
              <CardHeader>
                <div className="h-12 w-12 rounded-lg bg-accent/10 flex items-center justify-center mb-4 group-hover:bg-accent/20 transition-colors">
                  <Database className="h-6 w-6 text-accent" />
                </div>
                <CardTitle className="text-card-foreground">Data Engineering</CardTitle>
                <CardDescription>
                  Scalable data pipelines, cloud data platforms, and modern data warehousing architectures.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="group hover:shadow-xl transition-all duration-300 hover:-translate-y-1 border-border bg-card">
              <CardHeader>
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                  <BarChart3 className="h-6 w-6 text-primary" />
                </div>
                <CardTitle className="text-card-foreground">Data Analytics</CardTitle>
                <CardDescription>
                  Advanced analytics, statistical modeling, and data-driven insights for strategic decision-making.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="group hover:shadow-xl transition-all duration-300 hover:-translate-y-1 border-border bg-card">
              <CardHeader>
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                  <LineChart className="h-6 w-6 text-primary" />
                </div>
                <CardTitle className="text-card-foreground">Business Intelligence</CardTitle>
                <CardDescription>
                  Interactive dashboards, compelling visualizations, and self-service analytics enablement.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="group hover:shadow-xl transition-all duration-300 hover:-translate-y-1 border-border bg-card">
              <CardHeader>
                <div className="h-12 w-12 rounded-lg bg-accent/10 flex items-center justify-center mb-4 group-hover:bg-accent/20 transition-colors">
                  <Cloud className="h-6 w-6 text-accent" />
                </div>
                <CardTitle className="text-card-foreground">Cloud Platforms</CardTitle>
                <CardDescription>
                  Implementation and optimization on Azure, AWS, GCP, Databricks, and Snowflake.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="group hover:shadow-xl transition-all duration-300 hover:-translate-y-1 border-border bg-card">
              <CardHeader>
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                  <TrendingUp className="h-6 w-6 text-primary" />
                </div>
                <CardTitle className="text-card-foreground">Strategy & Consulting</CardTitle>
                <CardDescription>
                  Data strategy, technology assessment, and organizational capability building.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="group hover:shadow-xl transition-all duration-300 hover:-translate-y-1 border-border bg-card">
              <CardHeader>
                <div className="h-12 w-12 rounded-lg bg-accent/10 flex items-center justify-center mb-4 group-hover:bg-accent/20 transition-colors">
                  <Code2 className="h-6 w-6 text-accent" />
                </div>
                <CardTitle className="text-card-foreground">Custom Development</CardTitle>
                <CardDescription>
                  Tailored solutions, data integrations, and specialized implementations for unique needs.
                </CardDescription>
              </CardHeader>
            </Card>
          </div>

          <div className="text-center mt-12">
            <Link href="/services">
              <Button variant="outline" size="lg">
                View All Services
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Technology Stack */}
      <section className="py-20 bg-muted/30">
        <div className="container">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-4xl md:text-5xl font-bold mb-6 text-foreground">
                Technologies We Master
              </h2>
              <p className="text-xl text-muted-foreground">
                Expertise across industry-leading platforms and tools for modern data solutions.
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {technologies.map((tech) => (
                <Card key={tech.name} className="border-border bg-card hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <CardTitle className="text-lg text-card-foreground">{tech.name}</CardTitle>
                    <CardDescription className="text-xs">{tech.category}</CardDescription>
                  </CardHeader>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Section */}
      <section className="py-20 bg-background">
        <div className="container">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-4xl md:text-5xl font-bold mb-6 text-foreground">
                Why Data Decode Inc.
              </h2>
              <p className="text-xl text-muted-foreground">
                We combine deep technical expertise with strategic business acumen to deliver transformative data solutions.
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              <div className="text-center space-y-4">
                <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto">
                  <span className="text-2xl font-bold text-primary">✓</span>
                </div>
                <h3 className="text-xl font-semibold text-foreground">Enterprise Expertise</h3>
                <p className="text-muted-foreground">
                  Proven experience with Fortune 500 companies and complex data environments across industries.
                </p>
              </div>

              <div className="text-center space-y-4">
                <div className="h-16 w-16 rounded-full bg-accent/10 flex items-center justify-center mx-auto">
                  <span className="text-2xl font-bold text-accent">✓</span>
                </div>
                <h3 className="text-xl font-semibold text-foreground">Modern Stack</h3>
                <p className="text-muted-foreground">
                  Expertise with cutting-edge technologies and cloud platforms that scale with your business.
                </p>
              </div>

              <div className="text-center space-y-4">
                <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto">
                  <span className="text-2xl font-bold text-primary">✓</span>
                </div>
                <h3 className="text-xl font-semibold text-foreground">Results-Driven</h3>
                <p className="text-muted-foreground">
                  Focused on measurable ROI, performance optimization, and long-term business value.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-br from-primary/5 via-accent/5 to-background">
        <div className="container">
          <div className="max-w-4xl mx-auto text-center space-y-8">
            <h2 className="text-4xl md:text-5xl font-bold text-foreground">
              Ready to Transform Your Data?
            </h2>
            <p className="text-xl text-muted-foreground">
              Let's discuss how Data Decode Inc. can help you achieve your data and analytics goals.
            </p>
            <Link href="/contact">
              <Button size="lg" className="text-lg px-8 py-6">
                Schedule a Consultation
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
